Open a terminal and run "java -jar target/king-of-pop-1.0-SNAPSHOT.jar" to start the server.
The server runs on port 8888.